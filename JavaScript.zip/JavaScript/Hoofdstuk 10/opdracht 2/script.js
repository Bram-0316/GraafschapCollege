$(document).ready(function() {
    $('#Show').on('click', function(){
        $('#TOS').slideDown(600);
    })
    $('#Hide').on('click', function(){
        $('#TOS').slideUp(600);
    })

})