$('#elementID').on('click', function() {
    this.select();
});