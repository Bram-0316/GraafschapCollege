<?php

require_once ('header.php');

?>

<div class="page">
    <h1>informatie</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias assumenda illum voluptas praesentium consequatur nisi incidunt, vero adipisci? Voluptatum cum itaque omnis culpa quia aperiam.</p>
</div>


<?php

require_once ('footer.php');

?>