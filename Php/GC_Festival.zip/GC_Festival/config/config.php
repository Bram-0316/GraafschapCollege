<?php

//Path variables
define('PUBLIC_PATH', '../public');
define('IMAGE_FOLDER', '../public/images');
define('CSS_FOLDER', '../public/css');
define('STYLESHEET', '../public/css/style.css');
?>
