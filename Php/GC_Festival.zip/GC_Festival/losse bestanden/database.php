<?php

// Database variables
