
    <div class="page lineup">
        <div class="container">
            <h1>Line-up</h1>
            <div class="artists">
                
            </div>
        </div>
    </div>