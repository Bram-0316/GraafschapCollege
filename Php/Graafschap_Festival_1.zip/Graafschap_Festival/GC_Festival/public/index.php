<?php

require_once ('header.php');

?>


<div class="page home">
    <div class="container">
        <h1>Informatie</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo inventore magni mollitia numquam optio quam qui quod rem reprehenderit temporibus? Aspernatur consectetur consequuntur doloremque eos est eum fugiat officia voluptatem.</p>
    </div>
</div>


<?php

require_once ('footer.php');

?>